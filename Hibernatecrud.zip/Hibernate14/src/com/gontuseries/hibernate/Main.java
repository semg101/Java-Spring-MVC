package com.gontuseries.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

	public static void main(String[] args) {

		Student student = new Student();
		student.setStudent_name("Gontu1");
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		//here I am going to perform basic database operations using Hibernate provided functions
		session.save(student);
		student = (Student) session.get(Student.class, 1);
		
		System.out.println("Student Object having student name as:  " +student.getStudent_name());

		student.setStudent_name("Gontu1 modified");
		
		//session.delete(student);

		session.getTransaction().commit();
		session.close();
	}
}
